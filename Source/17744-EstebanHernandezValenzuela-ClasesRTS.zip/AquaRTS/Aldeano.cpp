// Fill out your copyright notice in the Description page of Project Settings.


#include "Aldeano.h"

AAldeano::AAldeano()
{
	health = 100;
	movementSpeed = 10;
}

void AAldeano::HarvestFood()
{
}

void AAldeano::HarvestMinerals()
{
}

void AAldeano::ReturnHome()
{
}

void AAldeano::Die()
{
}
