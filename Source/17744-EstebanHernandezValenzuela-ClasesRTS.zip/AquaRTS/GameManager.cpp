// Fill out your copyright notice in the Description page of Project Settings.


#include "GameManager.h"

void AGameManager::AddUnit(AActor* Unit)
{
}

void AGameManager::RemoveUnit(AActor* Unit)
{
}
